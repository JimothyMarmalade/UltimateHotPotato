"Ultimate Hot Potato" Demo Prototype created by Logan Edmund and Riahn Morton

Team up with a friend and attempt to deliver the hot potato to the goal at the end of the track.

The potato will respawn at the starting podium when it touches the ground or falls below the playing field. Players must attempt to catch it in the air before it falls. Additionally, each player can only hold the potato for a few seconds before it grows too hot to handle and will be forcibly ejected.

Player One - Mouse/Keyboard
Mouse       - Look
WASD        - Move
Left Click  - Grab/Throw
Space       - Jump
Q           - Reset Game

Player Two - Gamepad (Xbox controller, Dualshock, etc.)
Right Stick             - Look
Left Stick              - Move
South Button (Cross, A) - Jump
West Button (Square, X) - Grab/Throw